-- MySQL dump 10.13  Distrib 5.1.37, for pc-linux-gnu (i686)
--
-- Host: localhost    Database: iinvestor
-- ------------------------------------------------------
-- Server version	5.1.37
drop database if exists iinvestor;
create database iinvestor;
use iinvestor;
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bankingdetail`
--

DROP TABLE IF EXISTS `bankingdetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bankingdetail` (
  `user_code` varchar(20) NOT NULL,
  `bank_name` varchar(200) DEFAULT '',
  `bank_branch` varchar(200) DEFAULT '',
  `bank_city` varchar(200) DEFAULT '',
  `bank_account_number` varchar(20) DEFAULT '',
  `account_type` int(11) DEFAULT '0',
  `micr_number` varchar(20) DEFAULT '',
  `ifsc_code` varchar(20) DEFAULT '',
  `demat_ac_no` varchar(20) DEFAULT '' COMMENT 'It is the account where delivery of shares have been kept.',
  PRIMARY KEY (`user_code`),
  CONSTRAINT `FK_bankingdetail_1` FOREIGN KEY (`user_code`) REFERENCES `logindetail` (`user_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bankingdetail`
--

LOCK TABLES `bankingdetail` WRITE;
/*!40000 ALTER TABLE `bankingdetail` DISABLE KEYS */;
INSERT INTO `bankingdetail` VALUES ('C00000005','SBI','chd','qhd','21245458712',1,'65656','ITasa','6565'),('E00000002','SBI','sector 34A','Chandigarh','30802146655',1,'65421','it156','9898'),('E00000003','ICCI','Phase 7','Mohali','30865421398',2,'56454','it124','32356'),('E00000004','SBP','phase 1','ohali','12654789541',1,'98974','it478','65424'),('E00000006','Axis','34a','Chandigarh','308211451',2,'786','A786',''),('E00000007','SBP','34a chd','Chandigarh','30804201141',1,'1212','A007',''),('E0000010','','','','',0,'','',''),('E0000011','HDFFC','34A','CHD','',NULL,'3223','mASA','342342343'),('E0000012','','','','',0,'','',''),('E0000013','','','','',0,'','',''),('E000008','','','','',0,'','',''),('E000009','5645','456','456','',NULL,'546','456','456');
/*!40000 ALTER TABLE `bankingdetail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brokerage`
--

DROP TABLE IF EXISTS `brokerage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brokerage` (
  `brokerage_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_code` varchar(20) DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `brokerage_amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`brokerage_id`),
  KEY `FK_brokerage_1` (`client_code`),
  CONSTRAINT `FK_brokerage_1` FOREIGN KEY (`client_code`) REFERENCES `logindetail` (`user_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brokerage`
--

LOCK TABLES `brokerage` WRITE;
/*!40000 ALTER TABLE `brokerage` DISABLE KEYS */;
INSERT INTO `brokerage` VALUES (1,'C00000005','2011-01-03',1250);
/*!40000 ALTER TABLE `brokerage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `buysellshares`
--

DROP TABLE IF EXISTS `buysellshares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buysellshares` (
  `buy_sell_shares_id` int(11) NOT NULL AUTO_INCREMENT,
  `share_symbol` varchar(10) DEFAULT NULL,
  `exchange_share_code` int(11) DEFAULT NULL,
  `exchange_type` varchar(10) DEFAULT NULL,
  `client_code` varchar(20) DEFAULT NULL,
  `employee_code` varchar(20) DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `transaction_time` varchar(20) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `rate` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `transaction_status` int(11) DEFAULT NULL COMMENT 'It tells the nateure of the transaction whethet it is purchase transaction or sale transaction',
  PRIMARY KEY (`buy_sell_shares_id`),
  KEY `FK_buysellshares_1` (`share_symbol`),
  KEY `FK_buysellshares_2` (`client_code`),
  KEY `FK_buysellshares_3` (`employee_code`),
  CONSTRAINT `FK_buysellshares_1` FOREIGN KEY (`share_symbol`) REFERENCES `company` (`company_code`),
  CONSTRAINT `FK_buysellshares_2` FOREIGN KEY (`client_code`) REFERENCES `logindetail` (`user_code`),
  CONSTRAINT `FK_buysellshares_3` FOREIGN KEY (`employee_code`) REFERENCES `logindetail` (`user_code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buysellshares`
--

LOCK TABLES `buysellshares` WRITE;
/*!40000 ALTER TABLE `buysellshares` DISABLE KEYS */;
INSERT INTO `buysellshares` VALUES (1,'TCS',567567,'NSE','C00000005','E00000002','2011-01-09','10:24:26',30,800,24000,1),(2,'wipro',567567,'NSE','C00000005','E00000004','2011-01-10','10:28:27',10,500,5000,1);
/*!40000 ALTER TABLE `buysellshares` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `state_id` int(11) DEFAULT NULL,
  `city_name` varchar(200) DEFAULT NULL,
  `city_description` varchar(500) DEFAULT NULL,
  `city_status` int(11) DEFAULT NULL COMMENT 'It is used to activate or deactivate the city',
  PRIMARY KEY (`city_id`),
  KEY `state_id` (`state_id`),
  CONSTRAINT `state_id` FOREIGN KEY (`state_id`) REFERENCES `state` (`state_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `city`
--

LOCK TABLES `city` WRITE;
/*!40000 ALTER TABLE `city` DISABLE KEYS */;
INSERT INTO `city` VALUES (1,1,'Ropar','Ropar',1),(2,1,'Amritsar','Amritsar',1),(3,1,'Patiala','Patiala',1),(4,2,'Shimla','Shimla',1),(5,2,'Kangra','Kangra',1),(6,3,'Ambala','Ambala',1),(7,7,'Chandigarh','Chandigarh',1);
/*!40000 ALTER TABLE `city` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientassignmentdetail`
--

DROP TABLE IF EXISTS `clientassignmentdetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientassignmentdetail` (
  `assignment_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_code` varchar(20) DEFAULT NULL,
  `client_code` varchar(20) DEFAULT NULL,
  `assignment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `client_assignment_status` int(11) DEFAULT '1' COMMENT 'If client_assignment_status is 1  then it means client is currently assignrd to employee.If it is 0 then it means there is no assignment of client to the corresponding employee',
  PRIMARY KEY (`assignment_id`),
  KEY `FK_clientassignmentdetail_1` (`emp_code`),
  KEY `FK_clientassignmentdetail_2` (`client_code`),
  CONSTRAINT `FK_clientassignmentdetail_1` FOREIGN KEY (`emp_code`) REFERENCES `logindetail` (`user_code`),
  CONSTRAINT `FK_clientassignmentdetail_2` FOREIGN KEY (`client_code`) REFERENCES `logindetail` (`user_code`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientassignmentdetail`
--

LOCK TABLES `clientassignmentdetail` WRITE;
/*!40000 ALTER TABLE `clientassignmentdetail` DISABLE KEYS */;
INSERT INTO `clientassignmentdetail` VALUES (1,'E00000004','C00000005','2011-03-29 11:43:26',2),(2,'E00000004','C00000005','2011-03-29 13:04:52',2),(3,'E00000004','C00000005','2011-03-29 13:05:00',2),(4,'E00000004','C00000005','2011-03-29 13:09:48',2),(5,'E00000004','C00000005','2011-03-29 13:10:56',2),(6,'E00000004','C00000005','2011-03-29 13:10:57',1);
/*!40000 ALTER TABLE `clientassignmentdetail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientholding`
--

DROP TABLE IF EXISTS `clientholding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientholding` (
  `client_holding_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_code` varchar(20) DEFAULT NULL,
  `share_symbol` varchar(10) DEFAULT NULL,
  `exchange_share_code` int(11) DEFAULT NULL,
  `quantity` varchar(15) DEFAULT NULL,
  `holding_share_status` int(11) DEFAULT NULL COMMENT 'If tells the status of balance shares quantity of clients whether quantity becomes 0 or not. ',
  PRIMARY KEY (`client_holding_id`),
  KEY `share_code` (`exchange_share_code`),
  CONSTRAINT `share_code` FOREIGN KEY (`exchange_share_code`) REFERENCES `companyexchange` (`exchange_security_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientholding`
--

LOCK TABLES `clientholding` WRITE;
/*!40000 ALTER TABLE `clientholding` DISABLE KEYS */;
INSERT INTO `clientholding` VALUES (1,'C00000005','TCS',1001,'30',1);
/*!40000 ALTER TABLE `clientholding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientprofessionaldetail`
--

DROP TABLE IF EXISTS `clientprofessionaldetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientprofessionaldetail` (
  `client_code` varchar(20) NOT NULL,
  `office_address` varchar(500) DEFAULT '',
  `office_fax` varchar(16) DEFAULT '-',
  `occupation` varchar(100) DEFAULT 'NA',
  `education` varchar(100) DEFAULT 'NA',
  `income_group` varchar(45) DEFAULT 'NA',
  `industry` varchar(100) DEFAULT 'NA',
  `official_email_id` varchar(100) DEFAULT 'NA',
  `office_phone` varchar(16) DEFAULT '-',
  PRIMARY KEY (`client_code`),
  CONSTRAINT `FK_clientprofessionaldetail_1` FOREIGN KEY (`client_code`) REFERENCES `logindetail` (`user_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientprofessionaldetail`
--

LOCK TABLES `clientprofessionaldetail` WRITE;
/*!40000 ALTER TABLE `clientprofessionaldetail` DISABLE KEYS */;
INSERT INTO `clientprofessionaldetail` VALUES ('C00000005','sco 1011,sector 17A','0172-2116044','Doctor','MBBS','150000-300000','Pharma','mohit_kumar@gmail.com','0172-2116044');
/*!40000 ALTER TABLE `clientprofessionaldetail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientpurposedinvestment`
--

DROP TABLE IF EXISTS `clientpurposedinvestment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientpurposedinvestment` (
  `client_investment_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_code` varchar(20) DEFAULT NULL,
  `share_symbol` varchar(10) DEFAULT NULL,
  `exchange_share_code` int(11) DEFAULT NULL,
  `exchange_type` varchar(10) DEFAULT NULL,
  `buying_level` int(11) DEFAULT NULL,
  `selling_level` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `action_status` int(11) DEFAULT NULL COMMENT 'This tells the status of the share whether it has been purchased ,sold,or never purchased.',
  `company_status` int(11) DEFAULT NULL COMMENT 'I t tells the activation and deactivation detail about the company',
  PRIMARY KEY (`client_investment_id`),
  KEY `share_symbol` (`share_symbol`),
  KEY `client_code` (`client_code`),
  CONSTRAINT `client_code` FOREIGN KEY (`client_code`) REFERENCES `logindetail` (`user_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `share_symbol` FOREIGN KEY (`share_symbol`) REFERENCES `company` (`company_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientpurposedinvestment`
--

LOCK TABLES `clientpurposedinvestment` WRITE;
/*!40000 ALTER TABLE `clientpurposedinvestment` DISABLE KEYS */;
INSERT INTO `clientpurposedinvestment` VALUES (1,'C00000005','TCS',567567,'NSE',800,1008,10,1,1),(2,'C00000005','wipro',567567,'NSE',500,924,10,1,1);
/*!40000 ALTER TABLE `clientpurposedinvestment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(200) DEFAULT NULL,
  `company_code` varchar(10) DEFAULT NULL,
  `industry_name` varchar(200) DEFAULT NULL,
  `company_status` int(11) DEFAULT '1',
  PRIMARY KEY (`company_id`),
  UNIQUE KEY `Index_2` (`company_code`),
  UNIQUE KEY `Index_3` (`company_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (1,'TataConsultancyServicies','TCS','IT',1),(2,'wipro','wipro','IT',1),(3,'Microsoft','MSC','IT',1),(4,'SunMicrosystem','Sun','IT',1),(5,'AlphaITWorld','alpha','IT',1);
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company_quaterly_result`
--

DROP TABLE IF EXISTS `company_quaterly_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `company_quaterly_result` (
  `company_quaterly_result_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `quaterly_result_date` varchar(20) DEFAULT NULL,
  `sales_income` varchar(20) DEFAULT NULL,
  `expenditure` varchar(20) DEFAULT NULL,
  `interest_cover` varchar(20) DEFAULT NULL,
  `gross_profit` varchar(20) DEFAULT NULL,
  `depriciation` varchar(20) DEFAULT NULL,
  `tax` varchar(20) DEFAULT NULL,
  `pat` varchar(20) DEFAULT NULL,
  `equity` varchar(20) DEFAULT NULL,
  `OPM` varchar(5) DEFAULT NULL,
  `GPM` varchar(5) DEFAULT NULL,
  `NPM` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`company_quaterly_result_id`),
  KEY `FK_company_quaterly_result_1` (`company_id`),
  CONSTRAINT `FK_company_quaterly_result_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company_quaterly_result`
--

LOCK TABLES `company_quaterly_result` WRITE;
/*!40000 ALTER TABLE `company_quaterly_result` DISABLE KEYS */;
INSERT INTO `company_quaterly_result` VALUES (1,1,'2011-03-02','657.657','567.76','675.657','.6776','65.67','75.657','345.345','6575.765','65.67','-68.4','-54.8'),(2,2,'2011-03-11','345.35','3453.34','34534.435','3453.355','3453.345','3534.34534','3453.354','345.354','343.5','3454','3534'),(3,3,'2011-03-19','88988','889','779889','877','897','9787','798','8987','87','87','7878'),(4,4,'2011-03-20','88888','9999','99','999','9','656','989','898','989','9','9'),(5,5,'2002-03-30','1','11','11','11','1','11','1','11','111','1','1'),(6,5,'2008-03-30','1','11','11','11','11','1','11','11','11','11','1'),(7,5,'2010-03-30','1','1','1','11','11','1','11','11','1','11','1'),(8,5,'2003-03-30','1','1','1','1','1','1','1','1','1','1','1'),(14,5,'2011-02-03','2000000','200000','15','150000','232','1500','1220','154','88','98','79');
/*!40000 ALTER TABLE `company_quaterly_result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companycapitalstructure`
--

DROP TABLE IF EXISTS `companycapitalstructure`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companycapitalstructure` (
  `company_capital_structure_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `from_year` varchar(20) DEFAULT NULL,
  `to_year` varchar(20) DEFAULT NULL,
  `class_of_share` varchar(100) DEFAULT NULL,
  `authorised_capital` varchar(20) DEFAULT NULL,
  `issued_capital` varchar(20) DEFAULT NULL,
  `paid_up_shares` varchar(20) DEFAULT NULL,
  `face_value` varchar(15) DEFAULT NULL,
  `paid_up_capital` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`company_capital_structure_id`),
  KEY `FK_companycapitalstructure_1` (`company_id`),
  CONSTRAINT `FK_companycapitalstructure_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companycapitalstructure`
--

LOCK TABLES `companycapitalstructure` WRITE;
/*!40000 ALTER TABLE `companycapitalstructure` DISABLE KEYS */;
INSERT INTO `companycapitalstructure` VALUES (1,1,'2011','2012','equity share','1600000','1000000','1000000','1000000','1000000'),(2,2,'2011','2012','equity share','5000000','5646565','566565','15454','121545'),(3,3,'2011','2012','equity share','2100000','1500000','88999','98977','887778'),(4,4,'2011','2012','equiy share','6000000','5546000','66664','5884','444487'),(5,5,'2010','2011','nse','2','1','1','1','1'),(6,5,'2002','2003','NSE','1','1','21','21','212');
/*!40000 ALTER TABLE `companycapitalstructure` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companyexchange`
--

DROP TABLE IF EXISTS `companyexchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companyexchange` (
  `company_exchange_id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_security_code` int(11) DEFAULT NULL,
  `company_id` int(11) DEFAULT NULL,
  `exchange_abbr` varchar(10) DEFAULT NULL,
  `company_exchange_status` int(10) unsigned DEFAULT '1',
  PRIMARY KEY (`company_exchange_id`),
  KEY `Index_2` (`exchange_security_code`),
  KEY `FK_companyexchange_1` (`company_id`),
  CONSTRAINT `FK_companyexchange_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companyexchange`
--

LOCK TABLES `companyexchange` WRITE;
/*!40000 ALTER TABLE `companyexchange` DISABLE KEYS */;
INSERT INTO `companyexchange` VALUES (1,1001,1,'NSE',1),(2,1002,2,'NSE',1),(3,1003,3,'BSE',1),(4,1004,4,'NSE',1),(5,111,5,'NSE',1),(6,111,5,'BSE',1);
/*!40000 ALTER TABLE `companyexchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companyfundamentals`
--

DROP TABLE IF EXISTS `companyfundamentals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companyfundamentals` (
  `company_fundamentals_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `market_capitalization` varchar(20) DEFAULT '0',
  `book_value` varchar(10) DEFAULT '0',
  `debt_equity` varchar(5) DEFAULT '0',
  `P_E` varchar(5) DEFAULT '0',
  `Dividend_Yield` varchar(5) DEFAULT '0',
  `EPS` varchar(5) DEFAULT '0',
  `return_on_net_worth` varchar(5) DEFAULT '0',
  `current_ratio` varchar(5) DEFAULT '0',
  `quick_ration` varchar(5) DEFAULT '0',
  `intrest_cover` varchar(5) DEFAULT '0',
  PRIMARY KEY (`company_fundamentals_id`),
  KEY `FK_companyfundamentals_1` (`company_id`),
  CONSTRAINT `FK_companyfundamentals_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companyfundamentals`
--

LOCK TABLES `companyfundamentals` WRITE;
/*!40000 ALTER TABLE `companyfundamentals` DISABLE KEYS */;
INSERT INTO `companyfundamentals` VALUES (1,1,'5656','996','43','32','5345','8234','23','6723','23','87'),(2,2,'9987','898','89','.3','43','8342','65','0','32','88'),(3,3,'4541','654','22','33','5656','8744','98','6546','66','23'),(4,4,'7887','852','65','6','3491','9713','66','5656','23','32'),(5,5,'1','1','1','1','10','9','5','1','2','8');
/*!40000 ALTER TABLE `companyfundamentals` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companyshare`
--

DROP TABLE IF EXISTS `companyshare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companyshare` (
  `company_share_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_exchange_id` int(11) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `open_price` int(11) DEFAULT '0',
  `high_price` int(11) DEFAULT '0',
  `low_price` int(11) DEFAULT '0',
  `close_price` int(11) DEFAULT '0',
  `number_of_trades` varchar(20) DEFAULT NULL,
  `traded_quantity` varchar(20) DEFAULT NULL,
  `traded_value` varchar(25) DEFAULT NULL,
  `52_week_high` int(11) DEFAULT '0',
  `52_week_low` int(11) DEFAULT '0',
  PRIMARY KEY (`company_share_id`),
  KEY `company_exchange_id` (`company_exchange_id`),
  CONSTRAINT `company_exchange_id` FOREIGN KEY (`company_exchange_id`) REFERENCES `companyexchange` (`company_exchange_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companyshare`
--

LOCK TABLES `companyshare` WRITE;
/*!40000 ALTER TABLE `companyshare` DISABLE KEYS */;
INSERT INTO `companyshare` VALUES (1,1,'2011-01-01',12324,32423,23432,32012,'22','30','6565',20000,32000),(2,2,'2011-01-10',15000,25789,12521,25685,'32','29','2223',25699,12333),(3,5,'2011-03-30',2000,2500,1600,2450,'1','1','1',2500,0),(4,6,'2011-03-30',1800,2200,1500,2199,'1','1','1',2200,0);
/*!40000 ALTER TABLE `companyshare` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companysnapshot`
--

DROP TABLE IF EXISTS `companysnapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companysnapshot` (
  `company_snapshot_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) DEFAULT NULL,
  `registered_office` varchar(200) DEFAULT NULL,
  `telephone_number` varchar(15) DEFAULT NULL,
  `fax_number` varchar(15) DEFAULT 'NA',
  `website` varchar(100) DEFAULT 'NA',
  `chief_executive_name` varchar(200) DEFAULT NULL,
  `secretary_name` varchar(200) DEFAULT 'NA',
  `face_value` int(11) DEFAULT NULL,
  `market_lot` int(11) DEFAULT NULL,
  `business_group_name` varchar(200) DEFAULT NULL,
  `incorporation_date` date DEFAULT NULL,
  `registrar_of_company` varchar(200) DEFAULT NULL,
  `listed_on` varchar(100) DEFAULT 'NA',
  `company_snapshot_status` int(11) DEFAULT '1',
  PRIMARY KEY (`company_snapshot_id`),
  KEY `company_id` (`company_id`),
  CONSTRAINT `company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companysnapshot`
--

LOCK TABLES `companysnapshot` WRITE;
/*!40000 ALTER TABLE `companysnapshot` DISABLE KEYS */;
INSERT INTO `companysnapshot` VALUES (1,1,'chd - 56, 89','01722234564','01722234564','NA','raman verma','NA',7878,5565,'not available','2008-05-06','sec222, chd 78','chd, sector 12',1),(2,2,'chd - 56, 89','01722234564','01722234564','www.yahoo.com','raman verma','mohan sharma',4544,5565,'not available','2006-05-23','sec222, chd 78','chd, sector 12',1),(3,3,'chd - 56, 89','01722234564','01722234564','www.microsoft.com','Raj verma','mohan sharma',4545,5565,'not available','2011-02-08','sec222, chd 78','chd, sector 12',1),(4,4,'chd - 56, 89','01722234564','01722234564','NA','raman verma','NA',4545,5565,'not available','2008-05-06','sec222, chd 78','chd, sector 12',1),(5,5,'SCO 134,chd','0172211605','0172211605','www.aplhaitworld.net','Mr A Singh','Vipan Goyel',1,1,'Aplha','2002-03-30','abc','iii',1);
/*!40000 ALTER TABLE `companysnapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` varchar(200) DEFAULT NULL,
  `country_description` varchar(500) DEFAULT NULL,
  `country_status` int(11) DEFAULT NULL COMMENT 'It is used to activate or deactivate the country',
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country`
--

LOCK TABLES `country` WRITE;
/*!40000 ALTER TABLE `country` DISABLE KEYS */;
INSERT INTO `country` VALUES (1,'India','India',1),(2,'USA','USA',1),(3,'UK','UK',1);
/*!40000 ALTER TABLE `country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `designation`
--

DROP TABLE IF EXISTS `designation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `designation` (
  `designation_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `designation_title` varchar(45) DEFAULT NULL,
  `designation_description` varchar(200) DEFAULT NULL,
  `designation_status` int(11) DEFAULT '1',
  PRIMARY KEY (`designation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `designation`
--

LOCK TABLES `designation` WRITE;
/*!40000 ALTER TABLE `designation` DISABLE KEYS */;
INSERT INTO `designation` VALUES (1,'Developer','Software Developer',1),(2,'Computer Operator','computer operator',1),(3,'Doctor','MBBS',1);
/*!40000 ALTER TABLE `designation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `education`
--

DROP TABLE IF EXISTS `education`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `education` (
  `education_id` int(11) NOT NULL AUTO_INCREMENT,
  `education_title` varchar(45) DEFAULT NULL,
  `education_description` varchar(200) DEFAULT NULL,
  `education_status` int(11) DEFAULT '1' COMMENT 'It is used to activate or deactivate the  education degree',
  PRIMARY KEY (`education_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `education`
--

LOCK TABLES `education` WRITE;
/*!40000 ALTER TABLE `education` DISABLE KEYS */;
INSERT INTO `education` VALUES (1,'B.Tech.','Bachelor of technology',1),(2,'M.Tech','Master of Technologies',1),(3,'MCA','Master of Computer Application',1),(4,'MBA','Master of Business Administration',1),(5,'MBBS','MBBSabs',1);
/*!40000 ALTER TABLE `education` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empofficialdetail`
--

DROP TABLE IF EXISTS `empofficialdetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empofficialdetail` (
  `emp_code` varchar(20) NOT NULL,
  `office_address` varchar(500) DEFAULT '',
  `office_phone` varchar(15) DEFAULT '',
  `office_fax` varchar(16) DEFAULT '',
  `office_email_id` varchar(100) NOT NULL DEFAULT 'NA',
  `date_of_joining` date DEFAULT NULL,
  `job_profile` varchar(500) DEFAULT '',
  `current_salary_package` varchar(15) DEFAULT 'NA',
  `designation` varchar(100) DEFAULT 'NA',
  `date_of_relieve` date DEFAULT NULL,
  `education` varchar(100) DEFAULT 'NA',
  `skillset` varchar(100) DEFAULT '',
  `last_company_name` varchar(200) DEFAULT '',
  PRIMARY KEY (`emp_code`),
  CONSTRAINT `FK_empofficialdetail_1` FOREIGN KEY (`emp_code`) REFERENCES `logindetail` (`user_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empofficialdetail`
--

LOCK TABLES `empofficialdetail` WRITE;
/*!40000 ALTER TABLE `empofficialdetail` DISABLE KEYS */;
INSERT INTO `empofficialdetail` VALUES ('A00000001','sco o 1312 ','01722556654','017254545845','admin@yahoo.com','2011-02-11','Development','15000-30000','Developer',NULL,'MCA','Java','asda'),('C00000005','32323','0172565656','01724554545','client@yahoo.com','2011-03-02','Develop','15000-30000','Developer',NULL,'MCA','Java','aa'),('E00000002','sco 134-35,sector 34A','0172566441','0172566441','raman@alphaitworld.net','2011-01-01','Development','30000-50000','Developer',NULL,'MCA','Java','s'),('E00000003','Sco 123','0172256641','01724687448','msb@yahoo.com','2011-01-01','Development','15000-30000','Developer',NULL,'MCA','Java','aa'),('E00000004','sco 134-35,sector 34A','0172566441','0172566441','vinay@alphaitworld.net','2011-01-01','Development','45000-70000','Developer',NULL,'MCA','Java','s'),('E00000006','asds','0163325544111','017254698745','a@yahoo.com','2011-03-15','MJHOIJDYsj','150000-300000','Developer',NULL,'B.Tech.','java','a'),('E00000007','# 87987','01633258888','0163548989','abid@yahoo.in','2011-03-09','AA','150000-300000','Doctor',NULL,'MBBS','mbbs',''),('E0000010','','','','NA',NULL,'','NA','NA',NULL,'NA','',''),('E0000011','assdas','343242','34343','dasd@GMAIL.COM','2011-09-09','asdas','150000-300000','Developer',NULL,'M.Tech','asdsa','sads'),('E0000012','','','','NA',NULL,'','NA','NA',NULL,'NA','',''),('E0000013','','','','NA',NULL,'','NA','NA',NULL,'NA','',''),('E000008','','','','NA',NULL,'','NA','NA',NULL,'NA','',''),('E000009','23423','43534','43534','345s@fsdf','2011-05-24','fsdfsd','150000-300000','Developer',NULL,'B.Tech.','sdfsdf','435345');
/*!40000 ALTER TABLE `empofficialdetail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exchangetype`
--

DROP TABLE IF EXISTS `exchangetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchangetype` (
  `exchange_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `exchange_name` varchar(200) DEFAULT NULL,
  `exchange_abbr` varchar(10) DEFAULT NULL,
  `exchange_status` int(11) DEFAULT '1',
  PRIMARY KEY (`exchange_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchangetype`
--

LOCK TABLES `exchangetype` WRITE;
/*!40000 ALTER TABLE `exchangetype` DISABLE KEYS */;
INSERT INTO `exchangetype` VALUES (1,'NationalStockExchange','NSE',1),(2,'BombayStockExchange','BSE',1),(3,'Over The Counter Exchange Of India','OTCEI',1);
/*!40000 ALTER TABLE `exchangetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incomegroup`
--

DROP TABLE IF EXISTS `incomegroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `incomegroup` (
  `income_group_id` int(11) NOT NULL AUTO_INCREMENT,
  `income_range` varchar(45) DEFAULT NULL,
  `income_status` varchar(45) DEFAULT '1' COMMENT 'It is used to activate or deactivate the income group',
  PRIMARY KEY (`income_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incomegroup`
--

LOCK TABLES `incomegroup` WRITE;
/*!40000 ALTER TABLE `incomegroup` DISABLE KEYS */;
INSERT INTO `incomegroup` VALUES (1,'150000-300000','1'),(2,'300000-500000','1'),(3,'500000-700000','1');
/*!40000 ALTER TABLE `incomegroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `industry`
--

DROP TABLE IF EXISTS `industry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `industry` (
  `industry_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `industry_title` varchar(45) DEFAULT NULL,
  `industry_description` varchar(200) DEFAULT NULL,
  `industry_status` int(11) DEFAULT '1',
  PRIMARY KEY (`industry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `industry`
--

LOCK TABLES `industry` WRITE;
/*!40000 ALTER TABLE `industry` DISABLE KEYS */;
INSERT INTO `industry` VALUES (1,'IT','Information technology',1),(2,'Pharma','Science',1),(3,'n/w','Networking',1);
/*!40000 ALTER TABLE `industry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `investmentmanagement`
--

DROP TABLE IF EXISTS `investmentmanagement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `investmentmanagement` (
  `management_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_code` varchar(10) DEFAULT NULL,
  `exchange_abbr` varchar(10) DEFAULT NULL,
  `date_observed` date DEFAULT NULL,
  `allocation_date` date DEFAULT NULL,
  `deallocation_date` date DEFAULT NULL,
  `current_price` int(11) DEFAULT NULL,
  `min_target_price` int(11) DEFAULT NULL,
  `max_target_price` int(11) DEFAULT NULL,
  `investment_decision` varchar(10) DEFAULT NULL,
  `investment_report` varchar(1000) DEFAULT NULL,
  `basket_status` int(11) DEFAULT NULL,
  `implementation_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`management_id`),
  KEY `company_code` (`company_code`),
  CONSTRAINT `company_code` FOREIGN KEY (`company_code`) REFERENCES `company` (`company_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `investmentmanagement`
--

LOCK TABLES `investmentmanagement` WRITE;
/*!40000 ALTER TABLE `investmentmanagement` DISABLE KEYS */;
INSERT INTO `investmentmanagement` VALUES (1,'TCS','NSE','2011-01-01','2011-01-05','2011-03-13',1000,800,1500,'yes','yes',2,1),(2,'MSC','NSE','2011-01-03','2011-01-10','2011-03-05',1300,1100,1800,'yes','yes',2,1),(3,'Sun','BSE','2011-01-03','2011-01-12','2011-03-10',1250,1000,1500,'yes','yes',2,1);
/*!40000 ALTER TABLE `investmentmanagement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ledgermaster`
--

DROP TABLE IF EXISTS `ledgermaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ledgermaster` (
  `ledger_master_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_code` varchar(20) DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `balance_amount` varchar(20) DEFAULT NULL,
  `balance_type` int(11) DEFAULT NULL,
  PRIMARY KEY (`ledger_master_id`),
  KEY `FK_ledgermaster_1` (`client_code`),
  CONSTRAINT `FK_ledgermaster_1` FOREIGN KEY (`client_code`) REFERENCES `logindetail` (`user_code`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ledgermaster`
--

LOCK TABLES `ledgermaster` WRITE;
/*!40000 ALTER TABLE `ledgermaster` DISABLE KEYS */;
INSERT INTO `ledgermaster` VALUES (1,'C00000005','2011-01-06','20000',1);
/*!40000 ALTER TABLE `ledgermaster` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logindetail`
--

DROP TABLE IF EXISTS `logindetail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logindetail` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_code` varchar(20) DEFAULT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `user_type` int(11) DEFAULT NULL COMMENT 'It refers the type of the user.Whether it is administrator,manager,operator etc.',
  `user_status` int(11) DEFAULT '1' COMMENT 'It refers the status of the user.Whether it is logged in ,logged out etc.',
  `security_question` varchar(200) DEFAULT NULL,
  `security_answer` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `Index_2` (`user_code`),
  UNIQUE KEY `Index_3` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logindetail`
--

LOCK TABLES `logindetail` WRITE;
/*!40000 ALTER TABLE `logindetail` DISABLE KEYS */;
INSERT INTO `logindetail` VALUES (1,'A00000001','administrator','administrator1',1,1,'What is the name of your First School?','admin\r\n'),(2,'E00000002','raman11','administrator1',4,1,'What is the name of your favorite author?','raman11'),(3,'E00000003','manjeet','administrator1',2,1,'What is the name of your favorite author?','Aaaaaaaaaaaa'),(4,'E00000004','vinay','administrator1',2,1,'What is your first phone number?','9652112112'),(5,'C00000005','mohit','administrator1',3,1,'What is your first phone number?','9555566444'),(6,'E00000006','employee','administrator1',2,1,'What is the name of your First School?','ass'),(7,'E00000007','emp001','administrator1',2,1,'What is the name of your favorite author?','32323'),(8,'E000008','362','administrator1',2,1,'What is the name of your First School?','chgf'),(9,'E000009','dfs','administrator1',2,1,'What is the name of your First School?','sdfsd'),(10,'E0000010','3453','administrator1',2,1,'What is the name of your favorite author?','34534'),(11,'E0000011','Manjeet@yahoo.co.in','administrator1',2,1,'What is the name of your First School?','sjka'),(12,'E0000012','as','administrator1',2,1,'What is the name of your First School?','ASA'),(15,'E0000013','asa','administrator1',2,1,'What is the name of your First School?','asa');
/*!40000 ALTER TABLE `logindetail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `occupation`
--

DROP TABLE IF EXISTS `occupation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `occupation` (
  `occupation_id` int(11) NOT NULL AUTO_INCREMENT,
  `occupation_title` varchar(45) DEFAULT NULL,
  `occupation_status` int(11) DEFAULT '1',
  `occupation_description` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`occupation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `occupation`
--

LOCK TABLES `occupation` WRITE;
/*!40000 ALTER TABLE `occupation` DISABLE KEYS */;
INSERT INTO `occupation` VALUES (1,'Engineer',1,'computer science'),(2,'Doctor',1,'Pharma'),(3,'Scientist',1,'Science');
/*!40000 ALTER TABLE `occupation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personalinformation`
--

DROP TABLE IF EXISTS `personalinformation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `personalinformation` (
  `user_code` varchar(20) NOT NULL,
  `name_first` varchar(200) DEFAULT NULL,
  `name_middle` varchar(200) DEFAULT NULL,
  `name_last` varchar(200) DEFAULT NULL,
  `father_name_first` varchar(200) DEFAULT NULL,
  `father_name_middle` varchar(200) DEFAULT NULL,
  `father_name_last` varchar(200) DEFAULT NULL,
  `permanent_address` varchar(500) DEFAULT NULL,
  `current_address` varchar(500) DEFAULT NULL,
  `city` int(11) NOT NULL DEFAULT '1',
  `pincode` int(11) DEFAULT '0',
  `state` int(11) NOT NULL DEFAULT '1',
  `country` int(11) NOT NULL DEFAULT '1',
  `email_id` varchar(200) NOT NULL DEFAULT 'NA',
  `date_of_birth` varchar(70) DEFAULT NULL,
  `gender` varchar(45) DEFAULT NULL COMMENT 'Gender may be male or female',
  `residence_phone` varchar(16) DEFAULT '-',
  `mobile` varchar(15) DEFAULT NULL,
  `fax` varchar(16) DEFAULT '-',
  `pan` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_code`),
  KEY `user_code` (`user_code`),
  CONSTRAINT `FK_personalinformation_1` FOREIGN KEY (`user_code`) REFERENCES `logindetail` (`user_code`),
  CONSTRAINT `FK_personalinformation_user_code` FOREIGN KEY (`user_code`) REFERENCES `logindetail` (`user_code`),
  CONSTRAINT `user_code` FOREIGN KEY (`user_code`) REFERENCES `logindetail` (`user_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personalinformation`
--

LOCK TABLES `personalinformation` WRITE;
/*!40000 ALTER TABLE `personalinformation` DISABLE KEYS */;
INSERT INTO `personalinformation` VALUES ('A00000001','alpha','IT','World','Al[ha','It','Worlf','sco 134-35,sector 34A','sco 134-35,sector 34A',1,162054,1,1,'admin@alphaitworld.net','1967-02-11','Female','0172-21650451','9888888888','0172-21650451','4554545'),('C00000005','mohit','kumar','sharna','Raj','kumar','Sharama','#322 Sector 34,Chandigarh','#322 Sector 34,Chandigarh',1,162054,1,1,'mohit_kumar@yahoo.com','1987-03-12','Female','0172-21650451','9251122336','0172-21650451','145454'),('E00000002','Raman','Singh','Dhillon','Gurmit','Singh','Dhillon','V.P.O-Kharar,Mohali','#3232,Sector 11A',1,1620524,1,1,'raman_singh@yahoo.com','1987-01-01','Male','0172-21650451','9776996721','0172-21650451','8877777'),('E00000003','Manjeet','Singh','Brar','Reshem','Singh','Brar','v.p.o-rupana,Moga','#2116,Sector 21D',1,1620254,1,1,'manjeet_singh001@yahoo.in','1991-05-06','Male','0172-21650451','9803053680','0172-21650451','121231255'),('E00000004','Vinay','mohan','joshi','ram','mohan','joshi','#3212 Sector 44,Chandigarh','#3212 Sector 44,',1,1620524,1,1,'vinay_joshi12@gmail.com','1986-01-12','Male','0172-21650451','9292556681','0172-21650451','1212355'),('E00000006','A','Singh','Dhillon','B','Singh','Brar','#asdasd','AKjiksajfsa',1,152654,1,1,'a_singh@gmail.com','1990/03/09','Male','0172-656565','9569135644','0172-2116052','999999999'),('E00000007','abid','ali','khan','nusrat','fateh','ali','# 78,chd','# 21,22A chd',1,152044,1,1,'abid@gmail.com','1985/10/08','Male','0172-211755','9646367245','0176-525454897','21564'),('E0000010','Raman','Singh ','Brar','Harjinder','Singh','Brar','null','#awdas',1,8765,1,1,'raman@yahoo.com','2011-05-02','Female','0172-2011464','987945654','125654-12454','23423'),('E0000011','m','S','B','R`','S','B','ashjdkha','sdhasj',1,232,1,1,'sad@yahoo.com','2001-09-13','Female','0172-23423423','9914343402','0172-32343','34343'),('E0000012',NULL,' A A',' A','ASA ','ASA ','ASA ','\r\nASA\r\n','ASA\r\n',1,8989,1,1,'8989@989','2011-01-07','Male','232-23','2323','23-2323','23'),('E0000013','a ','asqa ','aa','fg','zzsas','f','dd','jkh',3,786,1,1,'767@67','67','Female','67-6','76','76-76','76'),('E000008','A','S','D','null','null','null','#szdsa','#asdsa',2,3243,1,1,'hggnmbm@yahoo.com','2011-05-18','Female','343234-34','343','3423-34','3434'),('E000009','343','asdsa','sad','sada','asd','asdas','asdasd','asd',1,32423,1,1,'24234@234234','2011-05-10','Female','3432-2342','324','3423-324234','324324');
/*!40000 ALTER TABLE `personalinformation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `receiptpayement`
--

DROP TABLE IF EXISTS `receiptpayement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `receiptpayement` (
  `receipt_payement_id` int(11) NOT NULL AUTO_INCREMENT,
  `client_code` varchar(10) DEFAULT NULL,
  `amount` varchar(20) DEFAULT NULL,
  `date_of_transaction` date DEFAULT NULL,
  `amount_status` int(11) DEFAULT NULL COMMENT 'It tells the nature of the amount whether it is receipt or payment',
  PRIMARY KEY (`receipt_payement_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `receiptpayement`
--

LOCK TABLES `receiptpayement` WRITE;
/*!40000 ALTER TABLE `receiptpayement` DISABLE KEYS */;
INSERT INTO `receiptpayement` VALUES (1,'C00000005','1000000','2011-03-01',1);
/*!40000 ALTER TABLE `receiptpayement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `state` (
  `state_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) DEFAULT NULL,
  `state_name` varchar(200) DEFAULT NULL,
  `state_description` varchar(500) DEFAULT NULL,
  `state_status` int(11) DEFAULT NULL COMMENT 'It is used to activate or deactivate the state',
  PRIMARY KEY (`state_id`),
  KEY `country_id` (`country_id`),
  CONSTRAINT `country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`country_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `state`
--

LOCK TABLES `state` WRITE;
/*!40000 ALTER TABLE `state` DISABLE KEYS */;
INSERT INTO `state` VALUES (1,1,'punjab','punjab',1),(2,1,'himachal','himachal',1),(3,1,'haryana','haryana',1),(4,2,'california','california',1),(5,3,'London','London',1),(6,2,'NewYork','NewYork',1),(7,1,'UT','UT',1);
/*!40000 ALTER TABLE `state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target`
--

DROP TABLE IF EXISTS `target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `target` (
  `target_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_code` varchar(20) DEFAULT NULL,
  `target_description` varchar(200) DEFAULT NULL COMMENT 'It refers the detail of the target',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `purposed_clients` int(11) DEFAULT NULL COMMENT 'It refers the targtet clients limit',
  `purposed_turnover` varchar(20) DEFAULT NULL COMMENT 'It refers the target turnover limit',
  `incoming_clients` int(11) DEFAULT '0',
  `outgoing_clients` int(11) DEFAULT '0',
  `turnover_achieved` varchar(20) DEFAULT '0',
  `target_status` int(11) DEFAULT '1' COMMENT 'It refers the status of the assigned target whether it is active,inactive,over or cancelled.',
  PRIMARY KEY (`target_id`),
  KEY `FK_target_1` (`emp_code`),
  CONSTRAINT `FK_target_1` FOREIGN KEY (`emp_code`) REFERENCES `logindetail` (`user_code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target`
--

LOCK TABLES `target` WRITE;
/*!40000 ALTER TABLE `target` DISABLE KEYS */;
INSERT INTO `target` VALUES (1,'E00000002','January 2011','2011-01-04','2011-01-24',1,'50000',0,0,'49000',1),(2,'E00000004','January 2011','2011-01-10','2011-01-30',2,'65000',0,0,'60000',1),(3,'E00000006','aa','2011-03-29','2011-04-28',2,'30000',0,0,'0',1),(4,'E00000006','aaa','2011-03-29','2011-03-31',3,'65',0,0,'0',1),(5,'E00000003','notavailable','2011-03-29','2011-04-08',5,'10000',0,0,'0',1);
/*!40000 ALTER TABLE `target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `turnovermaster`
--

DROP TABLE IF EXISTS `turnovermaster`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `turnovermaster` (
  `client_code` varchar(20) DEFAULT NULL,
  `turnover_amount` varchar(20) DEFAULT NULL,
  `last_update_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `turnovermaster`
--

LOCK TABLES `turnovermaster` WRITE;
/*!40000 ALTER TABLE `turnovermaster` DISABLE KEYS */;
INSERT INTO `turnovermaster` VALUES ('C00000005','68600','2011-03-14');
/*!40000 ALTER TABLE `turnovermaster` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2011-10-01 10:04:41
