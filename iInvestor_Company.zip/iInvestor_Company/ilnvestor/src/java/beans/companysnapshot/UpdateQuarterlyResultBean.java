/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package beans.companysnapshot;

/**
 *
 * @author student
 */
public class UpdateQuarterlyResultBean {
private String ddlYear,ddlMonth,txtSalesIncome,txtExpenditure,txtInterest,
        txtGrossProfit,txtDepriciation,txtTax,txtPat,txtEquity,txtOPM,txtGPM,
        txtNPM;

    public String getDdlMonth() {
        return ddlMonth;
    }

    public void setDdlMonth(String ddlMonth) {
        this.ddlMonth = ddlMonth;
    }

    public String getDdlYear() {
        return ddlYear;
    }

    public void setDdlYear(String ddlYear) {
        this.ddlYear = ddlYear;
    }

    public String getTxtDepriciation() {
        return txtDepriciation;
    }

    public void setTxtDepriciation(String txtDepriciation) {
        this.txtDepriciation = txtDepriciation;
    }

    public String getTxtEquity() {
        return txtEquity;
    }

    public void setTxtEquity(String txtEquity) {
        this.txtEquity = txtEquity;
    }

    public String getTxtExpenditure() {
        return txtExpenditure;
    }

    public void setTxtExpenditure(String txtExpenditure) {
        this.txtExpenditure = txtExpenditure;
    }

    public String getTxtGPM() {
        return txtGPM;
    }

    public void setTxtGPM(String txtGPM) {
        this.txtGPM = txtGPM;
    }

    public String getTxtGrossProfit() {
        return txtGrossProfit;
    }

    public void setTxtGrossProfit(String txtGrossProfit) {
        this.txtGrossProfit = txtGrossProfit;
    }

    public String getTxtInterest() {
        return txtInterest;
    }

    public void setTxtInterest(String txtInterest) {
        this.txtInterest = txtInterest;
    }

    public String getTxtNPM() {
        return txtNPM;
    }

    public void setTxtNPM(String txtNPM) {
        this.txtNPM = txtNPM;
    }

    public String getTxtOPM() {
        return txtOPM;
    }

    public void setTxtOPM(String txtOPM) {
        this.txtOPM = txtOPM;
    }

    public String getTxtPat() {
        return txtPat;
    }

    public void setTxtPat(String txtPat) {
        this.txtPat = txtPat;
    }

    public String getTxtSalesIncome() {
        return txtSalesIncome;
    }

    public void setTxtSalesIncome(String txtSalesIncome) {
        this.txtSalesIncome = txtSalesIncome;
    }

    public String getTxtTax() {
        return txtTax;
    }

    public void setTxtTax(String txtTax) {
        this.txtTax = txtTax;
    }

}
