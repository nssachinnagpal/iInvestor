/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package beans.companysnapshot;

/**
 *
 * @author student
 */
public class UpdateFundamentalsBean {
    private String companyid,companyname,txtMarketCapitalization,txtBookValue,txtDebtEquity,txtPE,
            txtDividendYield,txtEPS,txtReturn,txtCurrentRatio,txtQuickRatio,
            txtInterestCover;

    public String getCompanyname() {
        return companyname;
    }

    public String getCompanyid() {
        return companyid;
    }

    public void setCompanyid(String companyid) {
        this.companyid = companyid;
    }

    public void setCompanyname(String companyname) {
        this.companyname = companyname;
    }

    public String getTxtBookValue() {
        return txtBookValue;
    }

    public void setTxtBookValue(String txtBookValue) {
        this.txtBookValue = txtBookValue;
    }

    public String getTxtCurrentRatio() {
        return txtCurrentRatio;
    }

    public void setTxtCurrentRatio(String txtCurrentRatio) {
        this.txtCurrentRatio = txtCurrentRatio;
    }

    public String getTxtDebtEquity() {
        return txtDebtEquity;
    }

    public void setTxtDebtEquity(String txtDebtEquity) {
        this.txtDebtEquity = txtDebtEquity;
    }

    public String getTxtDividendYield() {
        return txtDividendYield;
    }

    public void setTxtDividendYield(String txtDividendYield) {
        this.txtDividendYield = txtDividendYield;
    }

    public String getTxtEPS() {
        return txtEPS;
    }

    public void setTxtEPS(String txtEPS) {
        this.txtEPS = txtEPS;
    }

    public String getTxtInterestCover() {
        return txtInterestCover;
    }

    public void setTxtInterestCover(String txtInterestCover) {
        this.txtInterestCover = txtInterestCover;
    }

    public String getTxtMarketCapitalization() {
        return txtMarketCapitalization;
    }

    public void setTxtMarketCapitalization(String txtMarketCapitalization) {
        this.txtMarketCapitalization = txtMarketCapitalization;
    }

    public String getTxtPE() {
        return txtPE;
    }

    public void setTxtPE(String txtPE) {
        this.txtPE = txtPE;
    }

    public String getTxtQuickRatio() {
        return txtQuickRatio;
    }

    public void setTxtQuickRatio(String txtQuickRatio) {
        this.txtQuickRatio = txtQuickRatio;
    }

    public String getTxtReturn() {
        return txtReturn;
    }

    public void setTxtReturn(String txtReturn) {
        this.txtReturn = txtReturn;
    }
    

}
