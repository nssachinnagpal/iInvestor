/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package beans.companysnapshot;

/**
 *
 * @author heena
 */
public class CompanyExchangeBean {
    private String companyid,exchangesecuritycode,companyexchangeid,exchangeabbr,
            companyexchangestatus;

    public String getCompanyexchangeid() {
        return companyexchangeid;
    }

    public void setCompanyexchangeid(String companyexchangeid) {
        this.companyexchangeid = companyexchangeid;
    }

    public String getCompanyexchangestatus() {
        return companyexchangestatus;
    }

    public void setCompanyexchangestatus(String companyexchangestatus) {
        this.companyexchangestatus = companyexchangestatus;
    }

    public String getCompanyid() {
        return companyid;
    }

    public void setCompanyid(String companyid) {
        this.companyid = companyid;
    }

    public String getExchangeabbr() {
        return exchangeabbr;
    }

    public void setExchangeabbr(String exchangeabbr) {
        this.exchangeabbr = exchangeabbr;
    }

    public String getExchangesecuritycode() {
        return exchangesecuritycode;
    }

    public void setExchangesecuritycode(String exchangesecuritycode) {
        this.exchangesecuritycode = exchangesecuritycode;
    }
    


}
