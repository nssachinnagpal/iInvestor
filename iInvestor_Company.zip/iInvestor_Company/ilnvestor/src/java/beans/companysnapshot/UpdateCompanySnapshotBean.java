/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package beans.companysnapshot;

/**
 *
 * @author student
 */
public class UpdateCompanySnapshotBean {
    private String companyid,companyname,industryname,taRegisteredOffice,txtPhoneNumber,txtFax,txtWebsite,txtChiefExecutiveName,
            txtSecretaryName,txtFaceValue,txtMarketLot,txtBusinessGroupName,
            txtIncorporationDate,taRegistrarOfCompany,txtListedOn;

    public String getIndustryname() {
        return industryname;
    }

    public void setIndustryname(String industryname) {
        this.industryname = industryname;
    }

    public String getCompanyid() {
        return companyid;
    }

    public void setCompanyid(String companyid) {
        this.companyid = companyid;
    }

    public String getCompanyname() {
        return companyname;
    }

    public void setCompanyname(String companyname) {
        this.companyname = companyname;
    }

   

    public String getTaRegisteredOffice() {
        return taRegisteredOffice;
    }

    public void setTaRegisteredOffice(String taRegisteredOffice) {
        this.taRegisteredOffice = taRegisteredOffice;
    }

    public String getTaRegistrarOfCompany() {
        return taRegistrarOfCompany;
    }

    public void setTaRegistrarOfCompany(String taRegistrarOfCompany) {
        this.taRegistrarOfCompany = taRegistrarOfCompany;
    }

    public String getTxtBusinessGroupName() {
        return txtBusinessGroupName;
    }

    public void setTxtBusinessGroupName(String txtBusinessGroupName) {
        this.txtBusinessGroupName = txtBusinessGroupName;
    }

    public String getTxtChiefExecutiveName() {
        return txtChiefExecutiveName;
    }

    public void setTxtChiefExecutiveName(String txtChiefExecutiveName) {
        this.txtChiefExecutiveName = txtChiefExecutiveName;
    }

    public String getTxtFaceValue() {
        return txtFaceValue;
    }

    public void setTxtFaceValue(String txtFaceValue) {
        this.txtFaceValue = txtFaceValue;
    }

    public String getTxtFax() {
        return txtFax;
    }

    public void setTxtFax(String txtFax) {
        this.txtFax = txtFax;
    }

    public String getTxtIncorporationDate() {
        return txtIncorporationDate;
    }

    public void setTxtIncorporationDate(String txtIncorporationDate) {
        this.txtIncorporationDate = txtIncorporationDate;
    }

    public String getTxtListedOn() {
        return txtListedOn;
    }

    public void setTxtListedOn(String txtListedOn) {
        this.txtListedOn = txtListedOn;
    }

    public String getTxtMarketLot() {
        return txtMarketLot;
    }

    public void setTxtMarketLot(String txtMarketLot) {
        this.txtMarketLot = txtMarketLot;
    }

    public String getTxtPhoneNumber() {
        return txtPhoneNumber;
    }

    public void setTxtPhoneNumber(String txtPhoneNumber) {
        this.txtPhoneNumber = txtPhoneNumber;
    }

    public String getTxtSecretaryName() {
        return txtSecretaryName;
    }

    public void setTxtSecretaryName(String txtSecretaryName) {
        this.txtSecretaryName = txtSecretaryName;
    }

    public String getTxtWebsite() {
        return txtWebsite;
    }

    public void setTxtWebsite(String txtWebsite) {
        this.txtWebsite = txtWebsite;
    }
    

}
