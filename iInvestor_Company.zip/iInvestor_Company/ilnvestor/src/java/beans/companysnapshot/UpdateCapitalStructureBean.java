/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package beans.companysnapshot;

/**
 *
 * @author student
 */
public class UpdateCapitalStructureBean {
    private String ddlFromYear,txtToYear,txtClassOfShare,txtAuthorisedCapital,
            txtIssuedCapital,txtPaidUpShares,txtFaceValue,txtPaidUpCapital;

    public String getDdlFromYear() {
        return ddlFromYear;
    }

    public void setDdlFromYear(String ddlFromYear) {
        this.ddlFromYear = ddlFromYear;
    }

    public String getTxtAuthorisedCapital() {
        return txtAuthorisedCapital;
    }

    public void setTxtAuthorisedCapital(String txtAuthorisedCapital) {
        this.txtAuthorisedCapital = txtAuthorisedCapital;
    }

    public String getTxtClassOfShare() {
        return txtClassOfShare;
    }

    public void setTxtClassOfShare(String txtClassOfShare) {
        this.txtClassOfShare = txtClassOfShare;
    }

    public String getTxtFaceValue() {
        return txtFaceValue;
    }

    public void setTxtFaceValue(String txtFaceValue) {
        this.txtFaceValue = txtFaceValue;
    }

    public String getTxtIssuedCapital() {
        return txtIssuedCapital;
    }

    public void setTxtIssuedCapital(String txtIssuedCapital) {
        this.txtIssuedCapital = txtIssuedCapital;
    }

    public String getTxtPaidUpCapital() {
        return txtPaidUpCapital;
    }

    public void setTxtPaidUpCapital(String txtPaidUpCapital) {
        this.txtPaidUpCapital = txtPaidUpCapital;
    }

    public String getTxtPaidUpShares() {
        return txtPaidUpShares;
    }

    public void setTxtPaidUpShares(String txtPaidUpShares) {
        this.txtPaidUpShares = txtPaidUpShares;
    }

    public String getTxtToYear() {
        return txtToYear;
    }

    public void setTxtToYear(String txtToYear) {
        this.txtToYear = txtToYear;
    }
    

}
