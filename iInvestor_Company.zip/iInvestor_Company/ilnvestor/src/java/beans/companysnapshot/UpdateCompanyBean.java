/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package beans.companysnapshot;

/**
 *
 * @author student
 */
public class UpdateCompanyBean {
    private String companyname,companycode,exchangeid,txtDate,txtOpenPrice0,txtOpenPrice1,txtHighPrice0,txtHighPrice1,
            txtLowPrice0,txtLowPrice1,txtClosePrice0,txtClosePrice1,txtTrades0,
            txtTrades1,txtTradedQuantity0,txtTradedQuantity1,txtTradedValue0,
            txtTradedValue1,txt52WeekHigh0,txt52WeekHigh1,txt52WeekLow0,txt52WeekLow1;

    public String getTxt52WeekHigh0() {
        return txt52WeekHigh0;
    }

    public String getExchangeid() {
        return exchangeid;
    }

    public void setExchangeid(String exchangeid) {
        this.exchangeid = exchangeid;
    }

    public void setTxt52WeekHigh0(String txt52WeekHigh0) {
        this.txt52WeekHigh0 = txt52WeekHigh0;
    }

    public String getTxt52WeekHigh1() {
        return txt52WeekHigh1;
    }

    public void setTxt52WeekHigh1(String txt52WeekHigh1) {
        this.txt52WeekHigh1 = txt52WeekHigh1;
    }

    public String getTxt52WeekLow0() {
        return txt52WeekLow0;
    }

    public void setTxt52WeekLow0(String txt52WeekLow0) {
        this.txt52WeekLow0 = txt52WeekLow0;
    }

    public String getTxt52WeekLow1() {
        return txt52WeekLow1;
    }

    public void setTxt52WeekLow1(String txt52WeekLow1) {
        this.txt52WeekLow1 = txt52WeekLow1;
    }

  

    public String getTxtClosePrice0() {
        return txtClosePrice0;
    }

    public String getCompanycode() {
        return companycode;
    }

    public void setCompanycode(String companycode) {
        this.companycode = companycode;
    }

    public String getCompanyname() {
        return companyname;
    }

    public void setCompanyname(String companyname) {
        this.companyname = companyname;
    }

    public void setTxtClosePrice0(String txtClosePrice0) {
        this.txtClosePrice0 = txtClosePrice0;
    }

    public String getTxtClosePrice1() {
        return txtClosePrice1;
    }

    public void setTxtClosePrice1(String txtClosePrice1) {
        this.txtClosePrice1 = txtClosePrice1;
    }

    public String getTxtDate() {
        return txtDate;
    }

    public void setTxtDate(String txtDate) {
        this.txtDate = txtDate;
    }

    public String getTxtHighPrice0() {
        return txtHighPrice0;
    }

    public void setTxtHighPrice0(String txtHighPrice0) {
        this.txtHighPrice0 = txtHighPrice0;
    }

    public String getTxtHighPrice1() {
        return txtHighPrice1;
    }

    public void setTxtHighPrice1(String txtHighPrice1) {
        this.txtHighPrice1 = txtHighPrice1;
    }

    public String getTxtLowPrice0() {
        return txtLowPrice0;
    }

    public void setTxtLowPrice0(String txtLowPrice0) {
        this.txtLowPrice0 = txtLowPrice0;
    }

    public String getTxtLowPrice1() {
        return txtLowPrice1;
    }

    public void setTxtLowPrice1(String txtLowPrice1) {
        this.txtLowPrice1 = txtLowPrice1;
    }

    public String getTxtOpenPrice0() {
        return txtOpenPrice0;
    }

    public void setTxtOpenPrice0(String txtOpenPrice0) {
        this.txtOpenPrice0 = txtOpenPrice0;
    }

    public String getTxtOpenPrice1() {
        return txtOpenPrice1;
    }

    public void setTxtOpenPrice1(String txtOpenPrice1) {
        this.txtOpenPrice1 = txtOpenPrice1;
    }

    public String getTxtTradedQuantity0() {
        return txtTradedQuantity0;
    }

    public void setTxtTradedQuantity0(String txtTradedQuantity0) {
        this.txtTradedQuantity0 = txtTradedQuantity0;
    }

    public String getTxtTradedQuantity1() {
        return txtTradedQuantity1;
    }

    public void setTxtTradedQuantity1(String txtTradedQuantity1) {
        this.txtTradedQuantity1 = txtTradedQuantity1;
    }

    public String getTxtTradedValue0() {
        return txtTradedValue0;
    }

    public void setTxtTradedValue0(String txtTradedValue0) {
        this.txtTradedValue0 = txtTradedValue0;
    }

    public String getTxtTradedValue1() {
        return txtTradedValue1;
    }

    public void setTxtTradedValue1(String txtTradedValue1) {
        this.txtTradedValue1 = txtTradedValue1;
    }

    public String getTxtTrades0() {
        return txtTrades0;
    }

    public void setTxtTrades0(String txtTrades0) {
        this.txtTrades0 = txtTrades0;
    }

    public String getTxtTrades1() {
        return txtTrades1;
    }

    public void setTxtTrades1(String txtTrades1) {
        this.txtTrades1 = txtTrades1;
    }
    

}
